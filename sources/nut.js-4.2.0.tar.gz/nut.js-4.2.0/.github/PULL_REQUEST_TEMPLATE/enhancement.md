---
name: Enhancement
about: Request to merge an enhancement
---

**Short summary**

**Detailed description (motivation, use-case etc.)**

**Screenshots (if appropriate)**

**Checklist**

- [ ] My change requires a change to the documentation.
- [ ] I have updated the documentation accordingly.
