---
name: Enhancement
about: Suggest a possible enhancement to the project
---

**Short overview**

**Use case**

**Detailed description**

**Additional content**

> Please provide any (mandatory) additional data for your enhancement
