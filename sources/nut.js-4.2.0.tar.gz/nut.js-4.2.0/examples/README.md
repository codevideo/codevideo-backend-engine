# nut.js examples

The projects contained in this folder are meant to be used as examples for how to use nut.js.
Especially the image matching samples will probably not run out of the box on you machine, nonetheless they should give you a good starting point for your own projects.