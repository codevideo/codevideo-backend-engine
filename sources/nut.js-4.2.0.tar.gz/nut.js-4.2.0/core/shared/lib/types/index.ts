export * from "./window-element.interface";
export * from "./window.interface";
export * from "./screen.types";