/**
 * {@link Button} enum represents clickable buttons of a mouse
 */
export enum Button {
  LEFT,
  MIDDLE,
  RIGHT,
}
