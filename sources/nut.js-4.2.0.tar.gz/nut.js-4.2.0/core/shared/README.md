# @nut-tree/shared

This package contains shared code to be used by the @nut-tree/nut-js and e.g. provider implementations.