# @nut-tree/provider-interfaces

This package contains all defined provider interfaces which can be used for custom implementations.
