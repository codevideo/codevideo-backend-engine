const POS_X = 50;
const POS_Y = 100;
const WIDTH = 400;
const HEIGHT = 300;
const TITLE = "libnut window test";

module.exports = {
  POS_X,
  POS_Y,
  WIDTH,
  HEIGHT,
  TITLE,
};
