import Clipboard from "./lib/clipboardy-clipboard.class";

export default Clipboard;
